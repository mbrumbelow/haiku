enum {
	R_BeLogoIcon = 14
};
